#include "defines.h"



void error(char* msg)
{
    printf("\nError : %s\n", msg);
    exit(1);
}



